--Query Store Configuration
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Desired_State_Desc] VARCHAR(255),
	  [Actual_State_Desc] VARCHAR(255),
	  [Query_Capture_Mode_Desc] VARCHAR(255),
	  [Size_Based_Cleanup_Mode_Desc] VARCHAR(255),
	  [Current_Storage_Size_MB] DEC,
	  [Flush_Interval_Seconds] INT,
	  [Interval_Length_Minutes] INT,
	  [Max_Storage_Size_MB] DEC,
	  [State_Query_Threshold_Days] INT,
	  [Max_Plans_Per_Query] INT,
	  [Collection Time] DATETIME
    ) ;
EXEC dbo.sp_MSforeachdb 'USE [?]; INSERT INTO #results
SELECT @@SERVERNAME as servername,
DB_NAME() AS [Database Name],
desired_state_desc,
actual_state_desc,
query_capture_mode_desc,
size_based_cleanup_mode_desc,
current_storage_size_mb,
flush_interval_seconds,
interval_length_minutes,
max_storage_size_mb,
stale_query_threshold_days,
max_plans_per_query,
CURRENT_TIMESTAMP AS [Collection Time]
from sys.database_query_store_options;'
SELECT * FROM #results ORDER BY 1,2,3
DROP TABLE #results
