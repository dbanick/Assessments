
/* CPU by Database */
WITH DB_CPU_Stats
AS
(SELECT DatabaseID, DB_Name(DatabaseID) AS [DatabaseName], SUM(total_worker_time) AS [CPU_Time_Ms]
 FROM sys.dm_exec_query_stats AS qs
 CROSS APPLY (SELECT CONVERT(INT, value) AS [DatabaseID] 
              FROM sys.dm_exec_plan_attributes(qs.plan_handle)
              WHERE attribute = N'dbid') AS F_DB
 GROUP BY DatabaseID)
SELECT @@SERVERNAME AS [Server Name], ROW_NUMBER() OVER(ORDER BY [CPU_Time_Ms] DESC) AS [Row Number],
       DatabaseName AS [Database Name], [CPU_Time_Ms] AS [CPU Time MS], 
       CAST([CPU_Time_Ms] * 1.0 / SUM([CPU_Time_Ms]) OVER() * 100.0 AS DECIMAL(5, 2)) AS [CPU Percent], 
	  CURRENT_TIMESTAMP AS [Collection Time] 
FROM DB_CPU_Stats
WHERE DatabaseID <> 32767 -- ResourceDB
ORDER BY [Row Number] OPTION (RECOMPILE);
