
/* Database Configuration */
SELECT
    @@SERVERNAME AS [Server Name],
    db.[name] AS [Database Name] ,
	db.state_desc AS [Database State],
    SUSER_SNAME(db.owner_sid) AS [Owner Name] ,
    db.recovery_model_desc AS [Recovery Model] ,
    db.log_reuse_wait_desc AS [Log Reuse Wait Description] ,
    ls.cntr_value AS [Log Size (KB)] ,
    lu.cntr_value AS [Log Used (KB)] ,
    CAST(CAST(lu.cntr_value AS FLOAT) / CAST(ls.cntr_value AS FLOAT) AS DECIMAL(18,
                                                              2)) * 100 AS [Log Used %] ,
    db.[compatibility_level] AS [Compatibility Level] ,
    db.page_verify_option_desc AS [Page Verify Option] ,
    db.is_auto_create_stats_on ,
    db.is_auto_update_stats_on ,
    db.is_auto_close_on ,
    db.is_auto_shrink_on ,
    db.is_auto_update_stats_async_on ,
    db.is_parameterization_forced ,
    db.snapshot_isolation_state_desc ,
    db.is_read_committed_snapshot_on ,
    db.is_master_key_encrypted_by_server ,
    db.is_encrypted , -- only in 2008
    db.is_published ,
    db.is_subscribed ,
    db.is_merge_published,
    CURRENT_TIMESTAMP AS [Collection Time] 
FROM
    sys.databases AS db
    INNER JOIN sys.dm_os_performance_counters AS lu ON db.name = lu.instance_name
    INNER JOIN sys.dm_os_performance_counters AS ls ON db.name = ls.instance_name
WHERE
    lu.counter_name LIKE N'Log File(s) Used Size (KB)%'
    AND ls.counter_name LIKE N'Log File(s) Size (KB)%'
    AND ls.cntr_value > 0
OPTION
    (RECOMPILE);
    