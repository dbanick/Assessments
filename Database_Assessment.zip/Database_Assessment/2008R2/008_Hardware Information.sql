
/* Hardware Information */
SELECT @@SERVERNAME AS [Server Name], cpu_count AS [Logical CPU Count], hyperthread_ratio AS [Hyperthread Ratio],
cpu_count/hyperthread_ratio AS [Physical CPU Count], 
physical_memory_in_bytes/1048576 AS [Physical Memory (MB)], 
sqlserver_start_time, affinity_type_desc, CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_os_sys_info OPTION (RECOMPILE);
