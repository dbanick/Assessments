DECLARE @command VARCHAR(4000)

IF OBJECT_ID('tempdb..#FileData', 'U') IS NOT NULL
BEGIN
	DROP TABLE tempdb..#FileData
END

CREATE TABLE tempdb..#FileData (
	[Database] VARCHAR(256) NULL
	,[FileType] VARCHAR(256) NULL
	,[File ID] INT
	,[Name] VARCHAR(256) NULL
	,[FileName] VARCHAR(256) NULL
	,[FileSize (MB)] DECIMAL(15, 2) NULL
	,[SpaceUsed (MB)] DECIMAL(15, 2) NULL
	,[AvailableSpace (MB)] DECIMAL(15, 2) NULL
	,[MaxSize (MB)] VARCHAR(64) NULL
	,[VolumeOrDrive] VARCHAR(256) NULL
	,[DriveFreeSpace (GB)] int NULL
	,[Collection Time] DATETIME
	)

BEGIN
	SET @command = 
		'USE [?]
		INSERT INTO #FileData (
			[Database]
			,[FileType]
			,[File ID]
			,[Name]
			,[FileName]
			,[FileSize (MB)]
			,[SpaceUsed (MB)]
			,[AvailableSpace (MB)]
			,[MaxSize (MB)]
			,[VolumeOrDrive]
			,[DriveFreeSpace (GB)]
			,[Collection Time]
			)
		SELECT CONVERT(VARCHAR(256), DB_NAME(v.database_id)) [DB]
			,CONVERT(VARCHAR(256), df.type_desc) [FileType]
			,df.file_id [File ID]
			,CONVERT(VARCHAR(256), f.name) [Name]
			,CONVERT(VARCHAR(256), f.[Filename]) [Filename]
			,CONVERT(DECIMAL(15, 2), ROUND(f.Size / 128.000, 2)) [FileSize (MB)]
			,CONVERT(DECIMAL(15, 2), ROUND(FILEPROPERTY(f.Name, ''SpaceUsed'') / 128.000, 2)) [SpaceUsed (MB)]
			,CONVERT(DECIMAL(15, 2), ROUND((f.Size - FILEPROPERTY(f.Name, ''SpaceUsed'')) / 128.000, 2)) [AvailableSpace (MB)]
			,CASE 
				WHEN f.maxsize = ''-1''
					THEN ''Unrestricted growth''
				ELSE LTRIM(STR(f.maxsize * 8.0 / 1024, 10, 1))
				END AS [MaxSize (MB)]
			,CONVERT(VARCHAR(256), v.volume_mount_point) [VolumeOrDrive]
			,CONVERT(DECIMAL(15, 2), v.available_bytes / 1073741824) [DriveFreeSpace (GB)]
			,CURRENT_TIMESTAMP AS [Collection Time] 
		FROM sys.sysfiles f WITH (NOLOCK)
		INNER JOIN sys.database_files df ON df.file_id = f.fileid
		CROSS APPLY sys.dm_os_volume_stats(DB_ID(), f.fileid) v;'
END -- END IF

EXEC sp_MSforeachdb @command

SELECT @@SERVERNAME [ServerName]
	,[Database]
	,[FileType]
	,[File ID]
	,[Name]
	,[FileName]
	,[FileSize (MB)]
	,[SpaceUsed (MB)]
	,[AvailableSpace (MB)]
	,CAST(ROUND([AvailableSpace (MB)] / [FileSize (MB)], 3) AS FLOAT) * 100 AS [% Free]
	,[MaxSize (MB)]
	,[VolumeOrDrive]
	,[DriveFreeSpace (GB)]
	,[Collection Time]
FROM #FileData

DROP TABLE tempdb..#FileData

