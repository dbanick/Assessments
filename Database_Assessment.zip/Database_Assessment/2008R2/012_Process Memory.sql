
/* SQL Server Process Address Space Information  */ 
/* Checks for internal memory pressure */
SELECT @@SERVERNAME AS [Server Name], physical_memory_in_use_kb,locked_page_allocations_kb, 
       page_fault_count, memory_utilization_percentage, 
       available_commit_limit_kb, process_physical_memory_low, 
       process_virtual_memory_low, CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.dm_os_process_memory OPTION (RECOMPILE);
