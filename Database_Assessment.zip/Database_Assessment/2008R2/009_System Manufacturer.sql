
/* System Manufacturer and Model Number */
CREATE TABLE #results
	(logdate DATETIME, processinfo VARCHAR(255), [Text] VARCHAR(255));
INSERT INTO #results
EXEC xp_readerrorlog 0,1,"Manufacturer"; 
SELECT @@SERVERNAME AS [Server Name], logdate AS [Log Date], processinfo AS [Process Info], [Text] AS [System Manufacturer], CURRENT_TIMESTAMP AS [Collection Time] FROM #results;
DROP TABLE #results;
