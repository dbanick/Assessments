/* Table Record Counts */
CREATE TABLE #results
	(
	  [Server Name] VARCHAR(128),
	  [Database Name] VARCHAR(128),
	  [Object Name] VARCHAR(260),
	  [Data Compression Description] VARCHAR(50),
	  [Row Count] BIGINT,
	  [Total Space MB] decimal,
	  [Used Space MB] decimal,
	  [Unused Space MB] decimal,
	  [Collection Time] DATETIME
	);
INSERT INTO #results
exec sp_MSforeachdb @command1 = 'USE [?];
SELECT @@SERVERNAME, DB_NAME(), OBJECT_NAME(p.object_id), p.data_compression_desc, SUM(p.Rows), 
    CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS TotalSpaceMB, 
    CAST(ROUND(((SUM(a.used_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) AS UsedSpaceMB, 
    CAST(ROUND(((SUM(a.total_pages) - SUM(a.used_pages)) * 8) / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSpaceMB,

CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.partitions p
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
WHERE p.index_id < 2 --ignore the partitions from the non-clustered index if any
AND OBJECT_NAME(p.object_id) NOT LIKE ''sys%''
AND OBJECT_NAME(p.object_id) NOT LIKE ''queue_%'' 
AND OBJECT_NAME(p.object_id) NOT LIKE ''filestream_tombstone%''
AND OBJECT_NAME(p.object_id) NOT LIKE ''fulltext%'' 
AND OBJECT_NAME(p.object_id) NOT LIKE N''ifts_comp_fragment%''
GROUP BY p.[object_id], p.data_compression_desc
ORDER BY SUM(p.Rows) DESC OPTION (RECOMPILE);'; 
SELECT * FROM #results;
DROP TABLE #results;