/* Database Configuration */
SELECT
	@@SERVERNAME AS [Server Name], 
	db.[name] AS [Database Name], 
	db.state_desc AS [Database State],
	SUSER_SNAME(db.owner_sid) AS [Owner Name],
	db.recovery_model_desc AS [Recovery Model], 
	db.containment_desc AS [Containment Description],
	db.log_reuse_wait_desc AS [Log Reuse Wait Description], 
	CONVERT(DECIMAL(18,2), ls.cntr_value/1024.0) AS [Log Size (MB)], 
	CONVERT(DECIMAL(18,2), lu.cntr_value/1024.0) AS [Log Used (MB)],
	CAST(CAST(lu.cntr_value AS FLOAT) / CAST(ls.cntr_value AS FLOAT)AS DECIMAL(18,2)) * 100 AS [Log Used %], 
	db.[compatibility_level] AS [Compatibility Level], 
	db.page_verify_option_desc AS [Page Verify Option], 
	db.is_auto_create_stats_on AS [Auto Create Stats On], 
	db.is_auto_update_stats_on AS [Auto Update Stats On], 
	db.is_auto_update_stats_async_on AS [Auto Update Stats Async On], 
	db.is_parameterization_forced AS [Parameterization Forced], 
	db.snapshot_isolation_state_desc AS [Snapshot Isolation State], 
	db.is_read_committed_snapshot_on AS [Read Committed Snapshot On], 
	db.is_auto_close_on AS [Auto Close On], 
	db.is_auto_shrink_on AS [Auto Shrink On], 
	db.target_recovery_time_in_seconds AS [Target Recovery Time (S)], 
	db.is_cdc_enabled AS [CDC Enabled], 
	db.is_trustworthy_on AS [Trustworthy On],
	db.is_cleanly_shutdown AS [Cleanly Shutdown],
	db.is_published AS [Published], 
	db.is_distributor AS [Distributor], 
	db.is_encrypted AS [Encrypted],
	db.group_database_id AS [Group Database ID], 
	db.replica_id AS [Replica ID],
	db.is_memory_optimized_elevate_to_snapshot_on AS [Memory Optimized Elevate To Snapshot On], 
	db.delayed_durability_desc AS [Delayed Durability], 
	db.is_auto_create_stats_incremental_on AS [Auto Create Stats Incremental On],
	db.is_query_store_on AS [Query Store On], 
	db.is_sync_with_backup AS [Sync With Backup], 
	db.is_supplemental_logging_enabled AS [Supplemental Logging Enabled], 
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.databases AS db WITH (NOLOCK)
	INNER JOIN sys.dm_os_performance_counters AS lu WITH (NOLOCK)
		ON db.name = lu.instance_name
	INNER JOIN sys.dm_os_performance_counters AS ls WITH (NOLOCK)
		ON db.name = ls.instance_name
WHERE lu.counter_name LIKE N'Log File(s) Used Size (KB)%' 
	AND ls.counter_name LIKE N'Log File(s) Size (KB)%'
	AND ls.cntr_value > 0 
ORDER BY db.[name] OPTION (RECOMPILE);