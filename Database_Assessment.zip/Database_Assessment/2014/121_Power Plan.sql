
DECLARE
@value VARCHAR(64),
@key VARCHAR(512) = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\'
+ 'ControlPanel\NameSpace\{025A5937-A6BE-4686-A844-36FE4BEC8B6D}';

EXEC master..xp_instance_regread
@rootkey = 'HKEY_LOCAL_MACHINE',
@key = @key,
@value_name = 'PreferredPlan',
@value = @value OUTPUT;


DECLARE
@value2 VARCHAR(64),
@key2 VARCHAR(512) = 'SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName';

EXEC master..xp_instance_regread
@rootkey = 'HKEY_LOCAL_MACHINE',
@key = @key2,
@value_name = 'ComputerName',
@value = @value2 OUTPUT;


SELECT  @value2 [ServerName],
	'This may be inaccurrate if the script was ran from a remote server; verify the Server Name matches the desired server' as Power_Plan,	
	CURRENT_TIMESTAMP AS [Collection Time]	

UNION ALL

SELECT  @value2 [ServerName],
	case 
	when @value = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' then 'High Performance Power Plan' 
	when @value = '381b4222-f694-41f0-9685-ff5bb260df2e' then 'Balanced Power Plan'
	when @value = 'a1841308-3541-4fab-bc81-f71556f20b4a' then 'Power Saver Plan'
	else 'Not High Performance Power Plan' end as Power_Plan,  
	CURRENT_TIMESTAMP AS [Collection Time]
