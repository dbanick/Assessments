/* Database Scoped Configuration */
CREATE TABLE #results
    (
	  [Server Name] VARCHAR(255),
      [Database Name] VARCHAR(255),
	  [Configuration ID] INT,
	  [Configuration Name] VARCHAR(60),
	  [Value for Primary] VARCHAR(100),
	  [Value for Secondary] VARCHAR(100),
	  [Collection Time] DATETIME
    );
INSERT INTO #results
EXEC sp_MSforeachdb @command1 = 'USE [?];
SELECT
	@@SERVERNAME AS [Server Name],
	DB_NAME() AS [Database Name],
	[configuration_id] AS [Configuration ID], 
	[name] AS [Configuration Name], 
	CONVERT(VARCHAR(255),[value]) AS [Value for Primary], 
	CONVERT(VARCHAR(255),[value_for_secondary]) AS [Value for Secondary],
	CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.database_scoped_configurations WITH (NOLOCK) OPTION (RECOMPILE);';
SELECT * FROM #results ORDER BY [Database Name], [Configuration ID];
DROP TABLE #results;