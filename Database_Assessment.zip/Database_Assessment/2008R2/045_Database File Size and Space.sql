
/* Database File Size and Free Space */
CREATE TABLE #results
    (
      [Server Name] VARCHAR(128),
      [Database Name] VARCHAR(128),
      [File Name] VARCHAR(128),
      [File ID] INT,
      [Physical File Name] VARCHAR(260),
      [Total Size in MB] FLOAT,
      [Available Space in MB] FLOAT,
	 [Collection Time] DATETIME
    );  
INSERT INTO #results
exec sp_MSforeachdb @command1 = 'USE [?]; 
SELECT CAST(SERVERPROPERTY(''ServerName'') AS VARCHAR(128)) AS [Server Name], 
''?'' AS [Database Name], 
f.name AS [File Name],
f.file_id AS [File ID],
f.physical_name AS [Physical File Name],  
size/128.0 AS ''[Total Size in MB]'', 
size/128.0 - CAST(FILEPROPERTY(name, ''SpaceUsed'') AS INT)/128.0 AS ''[Available Space in MB]'', CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.database_files f OPTION (RECOMPILE);' 
SELECT * FROM #results ORDER BY [Available Space in MB]
DROP TABLE #results;
