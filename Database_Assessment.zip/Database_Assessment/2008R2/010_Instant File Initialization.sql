
/* Instant File Initialization is Enabled */
CREATE TABLE #results
	([Output] VARCHAR(255));
begin try
INSERT INTO #results
EXEC xp_cmdshell 'whoami /priv';
end try
begin catch
INSERT INTO #results
SELECT 'Error occured. Please manually check via local security policy. '  as [Output]
end catch
SELECT @@SERVERNAME AS [Server Name], [Output] AS [Privileges Information], CURRENT_TIMESTAMP AS [Collection Time]
FROM #results WHERE [output] IS NOT NULL;
DROP TABLE #results;
