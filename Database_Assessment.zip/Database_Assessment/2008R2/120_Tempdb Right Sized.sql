USE tempdb
GO

SELECT @@SERVERNAME AS [Server]
	,o.cpu_count AS [Logical CPU Count]
	,count(*) AS [# of Data Files]
	,SUM(size) / 128 AS [Total Size (MB)]
	,SUM(size) / 128 / count(*) AS [Average Size]
	,CASE 
		WHEN min(size) <> max(size)
			THEN 'No'
		ELSE 'Yes'
		END AS [SizedEvenly]
	,CURRENT_TIMESTAMP AS [Collection Time]
FROM sys.database_files f
	,sys.dm_os_sys_info o
WHERE f.type_desc = 'ROWS'
GROUP BY o.cpu_count