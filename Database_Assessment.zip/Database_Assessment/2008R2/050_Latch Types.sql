
/* Latch Wait Types */
/* If LATCH_EX, LATCH_SH, or LATCH_UP is one of the top 3 or 4 from Wait Types then execute Latch Types */
/* Reference: http://www.sqlskills.com/BLOGS/PAUL/post/Most-common-latch-classes-(survey-results).aspx */
WITH [Latches] AS
    (SELECT
        [latch_class] As [Latch Class],
        [wait_time_ms] / 1000.0 AS [Wait (s)],
        [waiting_requests_count] AS [Wait Count],
        100.0 * [wait_time_ms] / SUM ([wait_time_ms]) OVER() AS [Percentage],
        ROW_NUMBER() OVER(ORDER BY [wait_time_ms] DESC) AS [RowNum]
    FROM sys.dm_os_latch_stats
    WHERE [latch_class] NOT IN (
        N'BUFFER')
    AND [wait_time_ms] > 0
    )
SELECT
    @@SERVERNAME AS [Server Name],
    [W1].[Latch Class] AS [Latch Class], 
    CAST ([W1].[Wait (s)] AS DECIMAL(14, 2)) AS [Wait (s)],
    [W1].[Wait Count] AS [Wait Count],
    CAST ([W1].[Percentage] AS DECIMAL(14, 2)) AS [Percentage],
    CAST (([W1].[Wait (s)] / [W1].[Wait Count]) AS DECIMAL (14, 4)) AS [Avg Wait (s)],
    CURRENT_TIMESTAMP AS [Collection Time]
FROM [Latches] AS [W1]
INNER JOIN [Latches] AS [W2]
    ON [W2].[RowNum] <= [W1].[RowNum]
WHERE [W1].[Wait Count] > 0
GROUP BY [W1].[RowNum], [W1].[Latch Class], [W1].[Wait (s)], [W1].[Wait Count], [W1].[Percentage]
HAVING SUM ([W2].[Percentage]) - [W1].[Percentage] < 95 OPTION (RECOMPILE);
