/* VLF Count */
/* 2012 */
CREATE TABLE #stage
    (
	  RecoveryUnitID INT, 
      FileID INT,
      FileSize BIGINT,
      StartOffset BIGINT,
      FSeqNo BIGINT,
      [Status] BIGINT,
      Parity BIGINT,
      CreateLSN NUMERIC(38)
    ) ;
CREATE TABLE #results
    (
      Database_Name SYSNAME,
      VLF_count INT
    ) ;
EXEC sp_MSforeachdb N'Use [?]; 
            INSERT INTO #stage 
            exec sp_executeSQL N''DBCC LOGINFO([?])''; 
            Insert Into #results 
            Select DB_Name(), Count(*) 
            From #stage; 
            Truncate Table #stage;'
SELECT  @@SERVERNAME AS [Server Name], Database_Name AS [Database Name], VLF_count AS [VLF Count]
FROM    #results
ORDER BY VLF_count DESC ;
DROP TABLE #stage ;
DROP TABLE #results ;
