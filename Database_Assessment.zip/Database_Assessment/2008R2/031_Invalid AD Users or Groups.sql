
/* Security principles without a corresponding AD account or group */
CREATE TABLE #results
(
    [SID] VARCHAR(255) ,
    [NT Login] VARCHAR(255)
)
INSERT INTO #results
EXEC [sys].[sp_validatelogins]  
SELECT @@SERVERNAME AS [Server Name], [SID], [NT Login], CURRENT_TIMESTAMP AS [Collection Time]  FROM #results ORDER BY [NT Login] OPTION (RECOMPILE);
DROP TABLE #results
