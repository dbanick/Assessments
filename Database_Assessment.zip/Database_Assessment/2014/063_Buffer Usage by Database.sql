/* Buffer Usage by Database */
SELECT
	@@SERVERNAME AS [Server Name],
   (CASE WHEN ([database_id] = 32767)
       THEN 'Resource Database'
       ELSE DB_NAME ([database_id]) END) AS [Database Name],
   COUNT (*) * 8 / 1024 AS [MB Used],
   SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024) AS [MB Empty],
   CAST(100.0 * (SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024)) / NULLIF((COUNT (*) * 8 / 1024),0) AS NUMERIC(20,2))  AS [Percent Empty],
   CURRENT_TIMESTAMP AS [Collection Time] 
FROM sys.dm_os_buffer_descriptors
GROUP BY [database_id]
ORDER BY [MB Used] DESC OPTION (RECOMPILE);
